This is a python implementation of the MAVLink protocol. 

Please see http://www.qgroundcontrol.org/mavlink/pymavlink for
documentation

License
-------

pymavlink is released under the GNU Lesser General Public License v3 or later
