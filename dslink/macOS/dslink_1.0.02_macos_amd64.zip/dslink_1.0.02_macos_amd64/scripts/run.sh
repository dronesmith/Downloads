#! /bin/sh

set -e

/opt/dslink/dslink --log /opt/dslink/log/dslink_`date +%s`.log
