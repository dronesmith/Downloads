#! /bin/sh

set -e

/opt/dslink/rundaemon.sh
