#! /bin/sh

set -e

/opt/dsengine/dsengine --log /opt/dsengine/log/dsengine_`date +%s`.log
