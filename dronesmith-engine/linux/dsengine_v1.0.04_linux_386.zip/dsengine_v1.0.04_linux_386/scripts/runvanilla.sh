#! /bin/sh

set -e

/opt/dsengine/dsengine
