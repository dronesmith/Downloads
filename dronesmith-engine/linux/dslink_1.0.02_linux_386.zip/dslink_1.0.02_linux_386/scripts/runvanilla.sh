#! /bin/sh

set -e

/opt/dslink/dslink
