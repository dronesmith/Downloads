#! /bin/sh

set -e

/opt/dsengine/rundaemon.sh
