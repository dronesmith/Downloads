function implement() {
    throw 'Not implemented';
}